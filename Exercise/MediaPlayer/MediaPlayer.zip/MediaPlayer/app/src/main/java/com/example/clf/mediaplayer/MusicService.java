package com.example.clf.mediaplayer;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.widget.Toast;

public class MusicService extends Service{
    //播放控制命令，标识操作
    public static final int COMMAND_UNKNOWN = -1;
    public static final int COMMAND_PLAY = 0;
    public static final int COMMAND_PAUSE=1;
    public static final int COMMAND_STOP=2;
    public static final int COMMAND_RESUME=3;
    public static final int COMMAND_PREVIOUS=4;
    public static final int COMMAND_NEXT=5;
    public static final int COMMAND_CHECK_IS_PLAYING=6;
    //播放状态
    public static final int STATUS_PLAYING=0;
    public static final int STATUS_PAUSED=1;
    public static final int STATUS_STOPPED=2;
    public static final int STATUS_COMPLETED=3;
    //广播标识
    public static final String BROADCAST_MUSICSERVICE_CONTROL="MusicService.ACTION_CONTROL";
    public static final String BROADCAST_MUSICSERVICE_UPDATE_STATUS="MusicService.ACTION_UPDATE";
    //广播接收器
    private CommandReceiver receiver;
    private MediaPlayer player;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate(){
        super.onCreate();
        bindCommandReceiver();
        Toast.makeText(this,"MusicService.onCreate()",Toast.LENGTH_LONG).show();
    }
    public void onStart(Intent intent,int startId){
        super.onStart(intent,startId);
    }

    public void onDestroy(){
        if(player!=null){
            player.release();
        }
        super.onDestroy();
    }




    private void load(int number) {
        //player=new MediaPlayer();
        //this.player.setAudioStreamType(AudioManager.STREAM_MUSIC);
        //this.player.setDataSource(musicUri); // 为本地的绝对路径，如/sdcard/abc/123.wav
        //this.player.prepare();
        //player.prepare();
        //player.start();
        //player.reset();
        try{
            if (player != null) {
                player.release();
            }
 /*player=new MediaPlayer();
            File file=new File(Environment.getExternalStorageDirectory(),null)G;
            player.setDataSource(file.getPath());
            player.prepare();*/

            Uri musicUri = Uri.withAppendedPath(
                    MediaStore.Audio.Media.INTERNAL_CONTENT_URI, /*"小星星.mp3"*/""+ number);
            player = MediaPlayer.create(this,musicUri);
/*Uri.parse("file://storage/emulated/0/kgmusic/download") musicUri)
;*/

            //player.prepare();
  /*player=new MediaPlayer();

           player.reset();
           player.setDataSource("content://media/external/audio/media");
           player.prepareAsync();
           player.start();*/
            player.setOnCompletionListener(completionListener);//注册监听器
            // player.prepare();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
//播放结束监听器
    MediaPlayer.OnCompletionListener completionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            if(mp.isLooping()){
                replay();
            }else{
                sendBroadcastOnStatusChanged(MusicService.STATUS_COMPLETED);
            }
        }
    };

    private void play(int number){
        if(player!=null && player.isPlaying()){
            player.stop();
        }
        load(number);
        player.start();
        sendBroadcastOnStatusChanged(MusicService.STATUS_PLAYING);
    }

    private void pause(){
        if(player.isPlaying()){
            player.pause();
            sendBroadcastOnStatusChanged(MusicService.STATUS_PAUSED);
        }
    }

    private void stop(){
        if(player!=null){
            player.stop();
            sendBroadcastOnStatusChanged(MusicService.STATUS_STOPPED);
        }
    }

    private void resume(){
        player.start();
        sendBroadcastOnStatusChanged(MusicService.STATUS_PLAYING);
    }

    private void replay(){
        player.start();
        sendBroadcastOnStatusChanged(MusicService.STATUS_PLAYING);
    }

   class CommandReceiver extends BroadcastReceiver{
        public void onReceive(Context context,Intent intent){
            //unregisterReceiver(this);
            //获取命令
            int command = intent.getIntExtra("command",COMMAND_UNKNOWN);
            //执行命令
            switch (command){
                case COMMAND_PLAY:
                case COMMAND_PREVIOUS:
                case COMMAND_NEXT:
                    int number = intent.getIntExtra("number",1);
                    Toast.makeText(MusicService.this,"正在播放第"+number+"首",Toast.LENGTH_LONG).show();
                    play(number);
                    break;
                case COMMAND_PAUSE:
                    pause();
                    break;
                case COMMAND_STOP:
                    stop();
                    break;
                case COMMAND_RESUME:
                    resume();
                    break;

                case COMMAND_CHECK_IS_PLAYING:
                    if(player.isPlaying()){
                        sendBroadcastOnStatusChanged(MusicService.STATUS_PLAYING);
                    }
                    break;
                case COMMAND_UNKNOWN:
                default:
                    break;
            }
        }
   }

   private void bindCommandReceiver(){
        receiver = new CommandReceiver();
       IntentFilter filter = new IntentFilter(BROADCAST_MUSICSERVICE_CONTROL);
       registerReceiver(receiver,filter);
   }

   private void sendBroadcastOnStatusChanged(int status){
        Intent intent=new Intent(BROADCAST_MUSICSERVICE_UPDATE_STATUS);
        intent.putExtra("status",status);
        sendBroadcast(intent);
   }

}
